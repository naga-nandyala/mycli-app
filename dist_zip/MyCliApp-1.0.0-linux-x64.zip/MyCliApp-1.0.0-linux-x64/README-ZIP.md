# MyCliApp Portable ZIP

Version: 1.0.0

This is a self-contained distribution of MyCliApp including a private
Python runtime (virtual environment). No system-level installation is
required; just extract and run.

## Quick Start (Windows)
```powershell
bin\mycli.cmd --version
bin\mycli.cmd status
bin\mycli.cmd login
```

## Quick Start (Linux / macOS)
```bash
chmod +x bin/mycli.sh
bin/mycli.sh --version
bin/mycli.sh status
```

## Adding to PATH (optional)
Add the `bin` directory to your PATH to invoke `mycli` from anywhere.

## Upgrading
Download a newer ZIP and replace this directory.

## Notes
* Built on: Linux-5.15.167.4-microsoft-standard-WSL2-x86_64-with-glibc2.39
* Invocation uses an internal venv in `python/`.
* Do not move files within the directory structure; launchers use
  relative paths.

## License
See `LICENSE`.
